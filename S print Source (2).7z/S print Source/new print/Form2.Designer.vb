﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.Bh1_font = New System.Windows.Forms.Button()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.Bth_color = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Troot_padding = New System.Windows.Forms.TextBox()
        Me.Ch1_align = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Th1_top = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Th1_bottom = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Th1_font_bold = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Tp_one_font_bold = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Tdiv_tow_bottom = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Tdiv_tow_top = New System.Windows.Forms.TextBox()
        Me.Cp_one_align = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Bp_one_font = New System.Windows.Forms.Button()
        Me.Ttable_one_border = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Th4_top = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Tdiv_one_top = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Ttable_one_top = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Timg_top_heigth = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Ttable_one_height = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Tpage_width = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Timg_log_heigth = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Timg_log_width = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Th4_font_bold = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Bh4_font = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Btr_color = New System.Windows.Forms.Button()
        Me.Ttable_tow_border = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Ttable_tow_td = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Ttr_border = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Btable_tow_font = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Bp_tow_font = New System.Windows.Forms.Button()
        Me.Tp_tow_bold = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Tdiv_thre_top = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Tdiv_thre_bottom = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.border_div_four = New System.Windows.Forms.TextBox()
        Me.Bh5_font = New System.Windows.Forms.Button()
        Me.Th5_bold = New System.Windows.Forms.TextBox()
        Me.Tdiv_four_top = New System.Windows.Forms.TextBox()
        Me.Timg_footer_hieght = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Th5_top = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Bh1_font
        '
        resources.ApplyResources(Me.Bh1_font, "Bh1_font")
        Me.Bh1_font.BackColor = System.Drawing.Color.Ivory
        Me.Bh1_font.FlatAppearance.BorderColor = System.Drawing.Color.Ivory
        Me.Bh1_font.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Ivory
        Me.Bh1_font.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Ivory
        Me.Bh1_font.Name = "Bh1_font"
        Me.ToolTip1.SetToolTip(Me.Bh1_font, resources.GetString("Bh1_font.ToolTip"))
        Me.Bh1_font.UseVisualStyleBackColor = False
        '
        'Bth_color
        '
        resources.ApplyResources(Me.Bth_color, "Bth_color")
        Me.Bth_color.BackColor = System.Drawing.Color.LightGray
        Me.Bth_color.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Bth_color.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Bth_color.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Bth_color.Name = "Bth_color"
        Me.ToolTip1.SetToolTip(Me.Bth_color, resources.GetString("Bth_color.ToolTip"))
        Me.Bth_color.UseVisualStyleBackColor = False
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Name = "Label1"
        Me.ToolTip1.SetToolTip(Me.Label1, resources.GetString("Label1.ToolTip"))
        '
        'Troot_padding
        '
        resources.ApplyResources(Me.Troot_padding, "Troot_padding")
        Me.Troot_padding.ForeColor = System.Drawing.Color.Black
        Me.Troot_padding.Name = "Troot_padding"
        Me.ToolTip1.SetToolTip(Me.Troot_padding, resources.GetString("Troot_padding.ToolTip"))
        '
        'Ch1_align
        '
        resources.ApplyResources(Me.Ch1_align, "Ch1_align")
        Me.Ch1_align.ForeColor = System.Drawing.Color.Black
        Me.Ch1_align.FormattingEnabled = True
        Me.Ch1_align.Items.AddRange(New Object() {resources.GetString("Ch1_align.Items"), resources.GetString("Ch1_align.Items1"), resources.GetString("Ch1_align.Items2")})
        Me.Ch1_align.Name = "Ch1_align"
        Me.ToolTip1.SetToolTip(Me.Ch1_align, resources.GetString("Ch1_align.ToolTip"))
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Name = "Label2"
        Me.ToolTip1.SetToolTip(Me.Label2, resources.GetString("Label2.ToolTip"))
        '
        'Th1_top
        '
        resources.ApplyResources(Me.Th1_top, "Th1_top")
        Me.Th1_top.ForeColor = System.Drawing.Color.Black
        Me.Th1_top.Name = "Th1_top"
        Me.ToolTip1.SetToolTip(Me.Th1_top, resources.GetString("Th1_top.ToolTip"))
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Name = "Label3"
        Me.ToolTip1.SetToolTip(Me.Label3, resources.GetString("Label3.ToolTip"))
        '
        'Th1_bottom
        '
        resources.ApplyResources(Me.Th1_bottom, "Th1_bottom")
        Me.Th1_bottom.ForeColor = System.Drawing.Color.Black
        Me.Th1_bottom.Name = "Th1_bottom"
        Me.ToolTip1.SetToolTip(Me.Th1_bottom, resources.GetString("Th1_bottom.ToolTip"))
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Name = "Label4"
        Me.ToolTip1.SetToolTip(Me.Label4, resources.GetString("Label4.ToolTip"))
        '
        'Th1_font_bold
        '
        resources.ApplyResources(Me.Th1_font_bold, "Th1_font_bold")
        Me.Th1_font_bold.ForeColor = System.Drawing.Color.Black
        Me.Th1_font_bold.Name = "Th1_font_bold"
        Me.ToolTip1.SetToolTip(Me.Th1_font_bold, resources.GetString("Th1_font_bold.ToolTip"))
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Name = "Label5"
        Me.ToolTip1.SetToolTip(Me.Label5, resources.GetString("Label5.ToolTip"))
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.Tp_one_font_bold)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Tdiv_tow_bottom)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Tdiv_tow_top)
        Me.GroupBox2.Controls.Add(Me.Cp_one_align)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Bp_one_font)
        Me.GroupBox2.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox2, resources.GetString("GroupBox2.ToolTip"))
        '
        'Tp_one_font_bold
        '
        resources.ApplyResources(Me.Tp_one_font_bold, "Tp_one_font_bold")
        Me.Tp_one_font_bold.ForeColor = System.Drawing.Color.Black
        Me.Tp_one_font_bold.Name = "Tp_one_font_bold"
        Me.ToolTip1.SetToolTip(Me.Tp_one_font_bold, resources.GetString("Tp_one_font_bold.ToolTip"))
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Name = "Label6"
        Me.ToolTip1.SetToolTip(Me.Label6, resources.GetString("Label6.ToolTip"))
        '
        'Tdiv_tow_bottom
        '
        resources.ApplyResources(Me.Tdiv_tow_bottom, "Tdiv_tow_bottom")
        Me.Tdiv_tow_bottom.ForeColor = System.Drawing.Color.Black
        Me.Tdiv_tow_bottom.Name = "Tdiv_tow_bottom"
        Me.ToolTip1.SetToolTip(Me.Tdiv_tow_bottom, resources.GetString("Tdiv_tow_bottom.ToolTip"))
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Name = "Label7"
        Me.ToolTip1.SetToolTip(Me.Label7, resources.GetString("Label7.ToolTip"))
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Name = "Label8"
        Me.ToolTip1.SetToolTip(Me.Label8, resources.GetString("Label8.ToolTip"))
        '
        'Tdiv_tow_top
        '
        resources.ApplyResources(Me.Tdiv_tow_top, "Tdiv_tow_top")
        Me.Tdiv_tow_top.ForeColor = System.Drawing.Color.Black
        Me.Tdiv_tow_top.Name = "Tdiv_tow_top"
        Me.ToolTip1.SetToolTip(Me.Tdiv_tow_top, resources.GetString("Tdiv_tow_top.ToolTip"))
        '
        'Cp_one_align
        '
        resources.ApplyResources(Me.Cp_one_align, "Cp_one_align")
        Me.Cp_one_align.ForeColor = System.Drawing.Color.Black
        Me.Cp_one_align.FormattingEnabled = True
        Me.Cp_one_align.Items.AddRange(New Object() {resources.GetString("Cp_one_align.Items"), resources.GetString("Cp_one_align.Items1"), resources.GetString("Cp_one_align.Items2"), resources.GetString("Cp_one_align.Items3")})
        Me.Cp_one_align.Name = "Cp_one_align"
        Me.ToolTip1.SetToolTip(Me.Cp_one_align, resources.GetString("Cp_one_align.ToolTip"))
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Name = "Label9"
        Me.ToolTip1.SetToolTip(Me.Label9, resources.GetString("Label9.ToolTip"))
        '
        'Bp_one_font
        '
        resources.ApplyResources(Me.Bp_one_font, "Bp_one_font")
        Me.Bp_one_font.BackColor = System.Drawing.Color.Ivory
        Me.Bp_one_font.FlatAppearance.BorderColor = System.Drawing.Color.Ivory
        Me.Bp_one_font.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Ivory
        Me.Bp_one_font.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Ivory
        Me.Bp_one_font.Name = "Bp_one_font"
        Me.ToolTip1.SetToolTip(Me.Bp_one_font, resources.GetString("Bp_one_font.ToolTip"))
        Me.Bp_one_font.UseVisualStyleBackColor = False
        '
        'Ttable_one_border
        '
        resources.ApplyResources(Me.Ttable_one_border, "Ttable_one_border")
        Me.Ttable_one_border.Name = "Ttable_one_border"
        Me.ToolTip1.SetToolTip(Me.Ttable_one_border, resources.GetString("Ttable_one_border.ToolTip"))
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        Me.ToolTip1.SetToolTip(Me.Label10, resources.GetString("Label10.ToolTip"))
        '
        'Th4_top
        '
        resources.ApplyResources(Me.Th4_top, "Th4_top")
        Me.Th4_top.Name = "Th4_top"
        Me.ToolTip1.SetToolTip(Me.Th4_top, resources.GetString("Th4_top.ToolTip"))
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        Me.ToolTip1.SetToolTip(Me.Label12, resources.GetString("Label12.ToolTip"))
        '
        'Tdiv_one_top
        '
        resources.ApplyResources(Me.Tdiv_one_top, "Tdiv_one_top")
        Me.Tdiv_one_top.Name = "Tdiv_one_top"
        Me.ToolTip1.SetToolTip(Me.Tdiv_one_top, resources.GetString("Tdiv_one_top.ToolTip"))
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        Me.ToolTip1.SetToolTip(Me.Label13, resources.GetString("Label13.ToolTip"))
        '
        'Ttable_one_top
        '
        resources.ApplyResources(Me.Ttable_one_top, "Ttable_one_top")
        Me.Ttable_one_top.ForeColor = System.Drawing.Color.Black
        Me.Ttable_one_top.Name = "Ttable_one_top"
        Me.ToolTip1.SetToolTip(Me.Ttable_one_top, resources.GetString("Ttable_one_top.ToolTip"))
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Name = "Label11"
        Me.ToolTip1.SetToolTip(Me.Label11, resources.GetString("Label11.ToolTip"))
        '
        'Timg_top_heigth
        '
        resources.ApplyResources(Me.Timg_top_heigth, "Timg_top_heigth")
        Me.Timg_top_heigth.Name = "Timg_top_heigth"
        Me.ToolTip1.SetToolTip(Me.Timg_top_heigth, resources.GetString("Timg_top_heigth.ToolTip"))
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        Me.ToolTip1.SetToolTip(Me.Label14, resources.GetString("Label14.ToolTip"))
        '
        'Ttable_one_height
        '
        resources.ApplyResources(Me.Ttable_one_height, "Ttable_one_height")
        Me.Ttable_one_height.Name = "Ttable_one_height"
        Me.ToolTip1.SetToolTip(Me.Ttable_one_height, resources.GetString("Ttable_one_height.ToolTip"))
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        Me.ToolTip1.SetToolTip(Me.Label15, resources.GetString("Label15.ToolTip"))
        '
        'GroupBox4
        '
        resources.ApplyResources(Me.GroupBox4, "GroupBox4")
        Me.GroupBox4.Controls.Add(Me.Label31)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.Tpage_width)
        Me.GroupBox4.Controls.Add(Me.Ttable_one_top)
        Me.GroupBox4.Controls.Add(Me.Label30)
        Me.GroupBox4.Controls.Add(Me.Troot_padding)
        Me.GroupBox4.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox4, resources.GetString("GroupBox4.ToolTip"))
        '
        'Label31
        '
        resources.ApplyResources(Me.Label31, "Label31")
        Me.Label31.BackColor = System.Drawing.Color.White
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Name = "Label31"
        Me.ToolTip1.SetToolTip(Me.Label31, resources.GetString("Label31.ToolTip"))
        '
        'Tpage_width
        '
        resources.ApplyResources(Me.Tpage_width, "Tpage_width")
        Me.Tpage_width.ForeColor = System.Drawing.Color.Black
        Me.Tpage_width.Name = "Tpage_width"
        Me.ToolTip1.SetToolTip(Me.Tpage_width, resources.GetString("Tpage_width.ToolTip"))
        '
        'Label30
        '
        resources.ApplyResources(Me.Label30, "Label30")
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Name = "Label30"
        Me.ToolTip1.SetToolTip(Me.Label30, resources.GetString("Label30.ToolTip"))
        '
        'Timg_log_heigth
        '
        resources.ApplyResources(Me.Timg_log_heigth, "Timg_log_heigth")
        Me.Timg_log_heigth.Name = "Timg_log_heigth"
        Me.ToolTip1.SetToolTip(Me.Timg_log_heigth, resources.GetString("Timg_log_heigth.ToolTip"))
        '
        'Label16
        '
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        Me.ToolTip1.SetToolTip(Me.Label16, resources.GetString("Label16.ToolTip"))
        '
        'Timg_log_width
        '
        resources.ApplyResources(Me.Timg_log_width, "Timg_log_width")
        Me.Timg_log_width.Name = "Timg_log_width"
        Me.ToolTip1.SetToolTip(Me.Timg_log_width, resources.GetString("Timg_log_width.ToolTip"))
        '
        'Label17
        '
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        Me.ToolTip1.SetToolTip(Me.Label17, resources.GetString("Label17.ToolTip"))
        '
        'Th4_font_bold
        '
        resources.ApplyResources(Me.Th4_font_bold, "Th4_font_bold")
        Me.Th4_font_bold.Name = "Th4_font_bold"
        Me.ToolTip1.SetToolTip(Me.Th4_font_bold, resources.GetString("Th4_font_bold.ToolTip"))
        '
        'Label18
        '
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        Me.ToolTip1.SetToolTip(Me.Label18, resources.GetString("Label18.ToolTip"))
        '
        'TabControl1
        '
        resources.ApplyResources(Me.TabControl1, "TabControl1")
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.ToolTip1.SetToolTip(Me.TabControl1, resources.GetString("TabControl1.ToolTip"))
        '
        'TabPage1
        '
        resources.ApplyResources(Me.TabPage1, "TabPage1")
        Me.TabPage1.BackColor = System.Drawing.Color.Ivory
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.Bh4_font)
        Me.TabPage1.Controls.Add(Me.Th4_font_bold)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Tdiv_one_top)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Timg_log_heigth)
        Me.TabPage1.Controls.Add(Me.Timg_top_heigth)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.Th4_top)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Ttable_one_height)
        Me.TabPage1.Controls.Add(Me.Timg_log_width)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.Ttable_one_border)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Name = "TabPage1"
        Me.ToolTip1.SetToolTip(Me.TabPage1, resources.GetString("TabPage1.ToolTip"))
        '
        'Bh4_font
        '
        resources.ApplyResources(Me.Bh4_font, "Bh4_font")
        Me.Bh4_font.BackColor = System.Drawing.Color.Ivory
        Me.Bh4_font.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Bh4_font.FlatAppearance.BorderColor = System.Drawing.Color.Ivory
        Me.Bh4_font.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Ivory
        Me.Bh4_font.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Ivory
        Me.Bh4_font.Image = Global.s_print.My.Resources.Resources.font_type
        Me.Bh4_font.Name = "Bh4_font"
        Me.ToolTip1.SetToolTip(Me.Bh4_font, resources.GetString("Bh4_font.ToolTip"))
        Me.Bh4_font.UseVisualStyleBackColor = False
        '
        'TabPage2
        '
        resources.ApplyResources(Me.TabPage2, "TabPage2")
        Me.TabPage2.BackColor = System.Drawing.Color.Ivory
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Name = "TabPage2"
        Me.ToolTip1.SetToolTip(Me.TabPage2, resources.GetString("TabPage2.ToolTip"))
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.Bh1_font)
        Me.GroupBox1.Controls.Add(Me.Th1_top)
        Me.GroupBox1.Controls.Add(Me.Th1_font_bold)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Ch1_align)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Th1_bottom)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox1, resources.GetString("GroupBox1.ToolTip"))
        '
        'TabPage3
        '
        resources.ApplyResources(Me.TabPage3, "TabPage3")
        Me.TabPage3.BackColor = System.Drawing.Color.Ivory
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage3.Controls.Add(Me.Btr_color)
        Me.TabPage3.Controls.Add(Me.Ttable_tow_border)
        Me.TabPage3.Controls.Add(Me.Label19)
        Me.TabPage3.Controls.Add(Me.Bth_color)
        Me.TabPage3.Controls.Add(Me.Ttable_tow_td)
        Me.TabPage3.Controls.Add(Me.Label20)
        Me.TabPage3.Controls.Add(Me.Ttr_border)
        Me.TabPage3.Controls.Add(Me.Label22)
        Me.TabPage3.Controls.Add(Me.Btable_tow_font)
        Me.TabPage3.Name = "TabPage3"
        Me.ToolTip1.SetToolTip(Me.TabPage3, resources.GetString("TabPage3.ToolTip"))
        '
        'Btr_color
        '
        resources.ApplyResources(Me.Btr_color, "Btr_color")
        Me.Btr_color.BackColor = System.Drawing.Color.LightGray
        Me.Btr_color.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Btr_color.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Btr_color.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Btr_color.Name = "Btr_color"
        Me.ToolTip1.SetToolTip(Me.Btr_color, resources.GetString("Btr_color.ToolTip"))
        Me.Btr_color.UseVisualStyleBackColor = False
        '
        'Ttable_tow_border
        '
        resources.ApplyResources(Me.Ttable_tow_border, "Ttable_tow_border")
        Me.Ttable_tow_border.Name = "Ttable_tow_border"
        Me.ToolTip1.SetToolTip(Me.Ttable_tow_border, resources.GetString("Ttable_tow_border.ToolTip"))
        '
        'Label19
        '
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.Name = "Label19"
        Me.ToolTip1.SetToolTip(Me.Label19, resources.GetString("Label19.ToolTip"))
        '
        'Ttable_tow_td
        '
        resources.ApplyResources(Me.Ttable_tow_td, "Ttable_tow_td")
        Me.Ttable_tow_td.Name = "Ttable_tow_td"
        Me.ToolTip1.SetToolTip(Me.Ttable_tow_td, resources.GetString("Ttable_tow_td.ToolTip"))
        '
        'Label20
        '
        resources.ApplyResources(Me.Label20, "Label20")
        Me.Label20.Name = "Label20"
        Me.ToolTip1.SetToolTip(Me.Label20, resources.GetString("Label20.ToolTip"))
        '
        'Ttr_border
        '
        resources.ApplyResources(Me.Ttr_border, "Ttr_border")
        Me.Ttr_border.Name = "Ttr_border"
        Me.ToolTip1.SetToolTip(Me.Ttr_border, resources.GetString("Ttr_border.ToolTip"))
        '
        'Label22
        '
        resources.ApplyResources(Me.Label22, "Label22")
        Me.Label22.Name = "Label22"
        Me.ToolTip1.SetToolTip(Me.Label22, resources.GetString("Label22.ToolTip"))
        '
        'Btable_tow_font
        '
        resources.ApplyResources(Me.Btable_tow_font, "Btable_tow_font")
        Me.Btable_tow_font.BackColor = System.Drawing.Color.Ivory
        Me.Btable_tow_font.FlatAppearance.BorderColor = System.Drawing.Color.Ivory
        Me.Btable_tow_font.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Ivory
        Me.Btable_tow_font.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Ivory
        Me.Btable_tow_font.Image = Global.s_print.My.Resources.Resources.font_type
        Me.Btable_tow_font.Name = "Btable_tow_font"
        Me.ToolTip1.SetToolTip(Me.Btable_tow_font, resources.GetString("Btable_tow_font.ToolTip"))
        Me.Btable_tow_font.UseVisualStyleBackColor = False
        '
        'TabPage4
        '
        resources.ApplyResources(Me.TabPage4, "TabPage4")
        Me.TabPage4.BackColor = System.Drawing.Color.Ivory
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage4.Controls.Add(Me.Bp_tow_font)
        Me.TabPage4.Controls.Add(Me.Tp_tow_bold)
        Me.TabPage4.Controls.Add(Me.Label21)
        Me.TabPage4.Controls.Add(Me.Tdiv_thre_top)
        Me.TabPage4.Controls.Add(Me.Label24)
        Me.TabPage4.Controls.Add(Me.Tdiv_thre_bottom)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Name = "TabPage4"
        Me.ToolTip1.SetToolTip(Me.TabPage4, resources.GetString("TabPage4.ToolTip"))
        '
        'Bp_tow_font
        '
        resources.ApplyResources(Me.Bp_tow_font, "Bp_tow_font")
        Me.Bp_tow_font.BackColor = System.Drawing.Color.Ivory
        Me.Bp_tow_font.FlatAppearance.BorderColor = System.Drawing.Color.Ivory
        Me.Bp_tow_font.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Ivory
        Me.Bp_tow_font.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Ivory
        Me.Bp_tow_font.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Bp_tow_font.Image = Global.s_print.My.Resources.Resources.font_type
        Me.Bp_tow_font.Name = "Bp_tow_font"
        Me.ToolTip1.SetToolTip(Me.Bp_tow_font, resources.GetString("Bp_tow_font.ToolTip"))
        Me.Bp_tow_font.UseVisualStyleBackColor = False
        '
        'Tp_tow_bold
        '
        resources.ApplyResources(Me.Tp_tow_bold, "Tp_tow_bold")
        Me.Tp_tow_bold.Name = "Tp_tow_bold"
        Me.ToolTip1.SetToolTip(Me.Tp_tow_bold, resources.GetString("Tp_tow_bold.ToolTip"))
        '
        'Label21
        '
        resources.ApplyResources(Me.Label21, "Label21")
        Me.Label21.Name = "Label21"
        Me.ToolTip1.SetToolTip(Me.Label21, resources.GetString("Label21.ToolTip"))
        '
        'Tdiv_thre_top
        '
        resources.ApplyResources(Me.Tdiv_thre_top, "Tdiv_thre_top")
        Me.Tdiv_thre_top.Name = "Tdiv_thre_top"
        Me.ToolTip1.SetToolTip(Me.Tdiv_thre_top, resources.GetString("Tdiv_thre_top.ToolTip"))
        '
        'Label24
        '
        resources.ApplyResources(Me.Label24, "Label24")
        Me.Label24.Name = "Label24"
        Me.ToolTip1.SetToolTip(Me.Label24, resources.GetString("Label24.ToolTip"))
        '
        'Tdiv_thre_bottom
        '
        resources.ApplyResources(Me.Tdiv_thre_bottom, "Tdiv_thre_bottom")
        Me.Tdiv_thre_bottom.Name = "Tdiv_thre_bottom"
        Me.ToolTip1.SetToolTip(Me.Tdiv_thre_bottom, resources.GetString("Tdiv_thre_bottom.ToolTip"))
        '
        'Label27
        '
        resources.ApplyResources(Me.Label27, "Label27")
        Me.Label27.Name = "Label27"
        Me.ToolTip1.SetToolTip(Me.Label27, resources.GetString("Label27.ToolTip"))
        '
        'TabPage5
        '
        resources.ApplyResources(Me.TabPage5, "TabPage5")
        Me.TabPage5.BackColor = System.Drawing.Color.Ivory
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage5.Controls.Add(Me.Label29)
        Me.TabPage5.Controls.Add(Me.Label26)
        Me.TabPage5.Controls.Add(Me.Label25)
        Me.TabPage5.Controls.Add(Me.Label34)
        Me.TabPage5.Controls.Add(Me.border_div_four)
        Me.TabPage5.Controls.Add(Me.Bh5_font)
        Me.TabPage5.Controls.Add(Me.Th5_bold)
        Me.TabPage5.Controls.Add(Me.Tdiv_four_top)
        Me.TabPage5.Controls.Add(Me.Timg_footer_hieght)
        Me.TabPage5.Controls.Add(Me.Label28)
        Me.TabPage5.Controls.Add(Me.Th5_top)
        Me.TabPage5.Name = "TabPage5"
        Me.ToolTip1.SetToolTip(Me.TabPage5, resources.GetString("TabPage5.ToolTip"))
        '
        'Label29
        '
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Name = "Label29"
        Me.ToolTip1.SetToolTip(Me.Label29, resources.GetString("Label29.ToolTip"))
        '
        'Label26
        '
        resources.ApplyResources(Me.Label26, "Label26")
        Me.Label26.Name = "Label26"
        Me.ToolTip1.SetToolTip(Me.Label26, resources.GetString("Label26.ToolTip"))
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        Me.ToolTip1.SetToolTip(Me.Label25, resources.GetString("Label25.ToolTip"))
        '
        'Label34
        '
        resources.ApplyResources(Me.Label34, "Label34")
        Me.Label34.Name = "Label34"
        Me.ToolTip1.SetToolTip(Me.Label34, resources.GetString("Label34.ToolTip"))
        '
        'border_div_four
        '
        resources.ApplyResources(Me.border_div_four, "border_div_four")
        Me.border_div_four.Name = "border_div_four"
        Me.ToolTip1.SetToolTip(Me.border_div_four, resources.GetString("border_div_four.ToolTip"))
        '
        'Bh5_font
        '
        resources.ApplyResources(Me.Bh5_font, "Bh5_font")
        Me.Bh5_font.BackColor = System.Drawing.Color.Ivory
        Me.Bh5_font.FlatAppearance.BorderColor = System.Drawing.Color.Ivory
        Me.Bh5_font.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Ivory
        Me.Bh5_font.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Ivory
        Me.Bh5_font.Image = Global.s_print.My.Resources.Resources.font_type
        Me.Bh5_font.Name = "Bh5_font"
        Me.ToolTip1.SetToolTip(Me.Bh5_font, resources.GetString("Bh5_font.ToolTip"))
        Me.Bh5_font.UseVisualStyleBackColor = False
        '
        'Th5_bold
        '
        resources.ApplyResources(Me.Th5_bold, "Th5_bold")
        Me.Th5_bold.Name = "Th5_bold"
        Me.ToolTip1.SetToolTip(Me.Th5_bold, resources.GetString("Th5_bold.ToolTip"))
        '
        'Tdiv_four_top
        '
        resources.ApplyResources(Me.Tdiv_four_top, "Tdiv_four_top")
        Me.Tdiv_four_top.Name = "Tdiv_four_top"
        Me.ToolTip1.SetToolTip(Me.Tdiv_four_top, resources.GetString("Tdiv_four_top.ToolTip"))
        '
        'Timg_footer_hieght
        '
        resources.ApplyResources(Me.Timg_footer_hieght, "Timg_footer_hieght")
        Me.Timg_footer_hieght.Name = "Timg_footer_hieght"
        Me.ToolTip1.SetToolTip(Me.Timg_footer_hieght, resources.GetString("Timg_footer_hieght.ToolTip"))
        '
        'Label28
        '
        resources.ApplyResources(Me.Label28, "Label28")
        Me.Label28.Name = "Label28"
        Me.ToolTip1.SetToolTip(Me.Label28, resources.GetString("Label28.ToolTip"))
        '
        'Th5_top
        '
        resources.ApplyResources(Me.Th5_top, "Th5_top")
        Me.Th5_top.Name = "Th5_top"
        Me.ToolTip1.SetToolTip(Me.Th5_top, resources.GetString("Th5_top.ToolTip"))
        '
        'Label23
        '
        resources.ApplyResources(Me.Label23, "Label23")
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label23.Name = "Label23"
        Me.ToolTip1.SetToolTip(Me.Label23, resources.GetString("Label23.ToolTip"))
        '
        'Button9
        '
        resources.ApplyResources(Me.Button9, "Button9")
        Me.Button9.BackColor = System.Drawing.Color.White
        Me.Button9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button9.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Ivory
        Me.Button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Ivory
        Me.Button9.Image = Global.s_print.My.Resources.Resources.Save18
        Me.Button9.Name = "Button9"
        Me.ToolTip1.SetToolTip(Me.Button9, resources.GetString("Button9.ToolTip"))
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Form2
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.GroupBox4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.ToolTip1.SetToolTip(Me, resources.GetString("$this.ToolTip"))
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents Bh1_font As System.Windows.Forms.Button
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents Bth_color As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Troot_padding As System.Windows.Forms.TextBox
    Friend WithEvents Ch1_align As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Th1_bottom As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Th1_top As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Tp_one_font_bold As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Tdiv_tow_bottom As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Tdiv_tow_top As System.Windows.Forms.TextBox
    Friend WithEvents Cp_one_align As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Bp_one_font As System.Windows.Forms.Button
    Friend WithEvents Th1_font_bold As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Ttable_one_border As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Th4_top As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Tdiv_one_top As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Bh4_font As System.Windows.Forms.Button
    Friend WithEvents Ttable_one_top As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Timg_top_heigth As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Ttable_one_height As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Timg_log_heigth As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Timg_log_width As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Th4_font_bold As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Ttable_tow_border As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Ttable_tow_td As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Ttr_border As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Btable_tow_font As System.Windows.Forms.Button
    Friend WithEvents Btr_color As System.Windows.Forms.Button
    Friend WithEvents Bp_tow_font As System.Windows.Forms.Button
    Friend WithEvents Tp_tow_bold As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Tdiv_thre_top As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Tdiv_thre_bottom As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Bh5_font As System.Windows.Forms.Button
    Friend WithEvents Th5_bold As System.Windows.Forms.TextBox
    Friend WithEvents Tdiv_four_top As System.Windows.Forms.TextBox
    Friend WithEvents Timg_footer_hieght As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Th5_top As System.Windows.Forms.TextBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents border_div_four As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Tpage_width As System.Windows.Forms.TextBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
End Class
